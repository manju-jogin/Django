from django.db import models

class Student(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()

class Parent(models.Model):
    student = models.OneToOneField(Student, on_delete=models.CASCADE)
    parent_name = models.CharField(max_length=100)

class Subject(models.Model):
    name = models.CharField(max_length=100)

class Marks(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    marks = models.IntegerField()